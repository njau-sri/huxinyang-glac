#!/bin/sh
python3 allele_count.py snpldb.vcf subpop.txt > allele_count.txt
