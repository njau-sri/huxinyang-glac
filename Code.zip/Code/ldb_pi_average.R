#！usr/bin/Rscript
pi.mean=function(infile)  {
  pi=read.table(infile,header = T)
  round(mean(pi[,3]),4)
}
pi.mean("w.sites.pi")
pi.mean("l.sites.pi")
pi.mean("r.sites.pi")
pi.mean("w.sc.sites.pi")
pi.mean("w.nc.sites.pi")
pi.mean("w.nec.sites.pi")
pi.mean("l.sc.sites.pi")
pi.mean("l.nc.sites.pi")
pi.mean("l.nec.sites.pi")
pi.mean("r.sc.sites.pi")
pi.mean("r.nc.sites.pi")
pi.mean("r.nec.sites.pi")