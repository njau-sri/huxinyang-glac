#！usr/bin/Rscript
#this project is edited by Hu Xinyang
#update in 2024/03/28

#Step 1: The raw data preparation
no.W=127;no.L=424;no.R=199
no.W.SC=63;no.W.NC=37;no.W.NEC=27
no.L.SC=328;no.L.NC=67;no.L.NEC=29
no.R.SC=84;no.R.NC=67;no.R.NEC=48
allele.count=read.table("allele_count.txt",header = T)
allele.count$ac.W=allele.count$ac.W.NEC+allele.count$ac.W.NC+allele.count$ac.W.SC
allele.count$ac.L=allele.count$ac.L.NEC+allele.count$ac.L.NC+allele.count$ac.L.SC
allele.count$ac.R=allele.count$ac.R.NEC+allele.count$ac.R.NC+allele.count$ac.R.SC

#Step 2: The population/sub-population allele number
dim(allele.count)[1]
sum(allele.count$ac.W>0);sum(allele.count$ac.L>0);sum(allele.count$ac.R>0)
sum(allele.count$ac.W.SC>0);sum(allele.count$ac.W.NC>0);sum(allele.count$ac.W.NEC>0)
sum(allele.count$ac.L.SC>0);sum(allele.count$ac.L.NC>0);sum(allele.count$ac.L.NEC>0)
sum(allele.count$ac.R.SC>0);sum(allele.count$ac.R.NC>0);sum(allele.count$ac.R.NEC>0)

#Step 3: The number of each allele type in the whole genome
#LR vs. WA
sum(allele.count$ac.W>0 & allele.count$ac.L>0)
sum(allele.count$ac.W==no.W & allele.count$ac.L==no.L)
sum(allele.count$ac.W<no.W & allele.count$ac.L==no.L)
sum(allele.count$ac.W==no.W & allele.count$ac.L<no.L)
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W &
	allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L))
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W &
	allele.count$ac.L<no.L & (allele.count$ac.W/no.W > allele.count$ac.L/no.L))
sum(allele.count$ac.W>0 & allele.count$ac.L==0)
sum(allele.count$ac.W==0 & allele.count$ac.L>0)
sum(allele.count$ac.W==0 & allele.count$ac.L==0)
#RC vs. LR
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R>0)
sum(allele.count$ac.W==0 & allele.count$ac.L>0 & allele.count$ac.R>0)
sum(allele.count$ac.L==no.L & allele.count$ac.R==no.R)
sum(allele.count$ac.L<no.L & allele.count$ac.R==no.R)
sum(allele.count$ac.L==no.L & allele.count$ac.R<no.R)
sum(allele.count$ac.L>0 & allele.count$ac.R>0 & allele.count$ac.L<no.L &
	allele.count$ac.R<no.R & (allele.count$ac.L/no.L < allele.count$ac.R/no.R))
sum(allele.count$ac.L>0 & allele.count$ac.R>0 & allele.count$ac.L<no.L &
	allele.count$ac.R<no.R & (allele.count$ac.L/no.L > allele.count$ac.R/no.R))
sum(allele.count$ac.L>0 & allele.count$ac.R==0)
sum(allele.count$ac.W>0 & allele.count$ac.L==0 & allele.count$ac.R>0)
sum(allele.count$ac.W==0 & allele.count$ac.L==0 & allele.count$ac.R>0)
sum(allele.count$ac.L==0 & allele.count$ac.R==0)

#Step 4: The number of each allele type in selective sweeps
allele.sweep=function(sweep.file) {
  sweeps=read.table(sweep.file,header = T)
  alleles=allele.count
  allele.sweep.data=NULL
  for (i in seq(dim(sweeps)[1]))  {
	  allele.sweep.data=rbind(allele.sweep.data,alleles[alleles[,2]==sweeps[i,1] &
		  alleles[,3]>=sweeps[i,2] & alleles[,3]<=sweeps[i,3],])}
  allele.sweep.data
}
#LR vs. WA
dom.sweep.allele=allele.sweep("sweep_domestication.reg")
dim(dom.sweep.allele)[1]
sum(dom.sweep.allele$ac.W==no.W & dom.sweep.allele$ac.L==no.L)
sum(dom.sweep.allele$ac.W<no.W & dom.sweep.allele$ac.L==no.L)
sum(dom.sweep.allele$ac.W==no.W & dom.sweep.allele$ac.L<no.L)
sum(dom.sweep.allele$ac.W>0 & dom.sweep.allele$ac.L>0 & dom.sweep.allele$ac.W<no.W &
	dom.sweep.allele$ac.L<no.L & (dom.sweep.allele$ac.W/no.W < dom.sweep.allele$ac.L/no.L))
sum(dom.sweep.allele$ac.W>0 & dom.sweep.allele$ac.L>0 & dom.sweep.allele$ac.W<no.W &
	dom.sweep.allele$ac.L<no.L & (dom.sweep.allele$ac.W/no.W > dom.sweep.allele$ac.L/no.L))
sum(dom.sweep.allele$ac.W>0 & dom.sweep.allele$ac.L==0)
sum(dom.sweep.allele$ac.W==0 & dom.sweep.allele$ac.L>0)
sum(dom.sweep.allele$ac.W==0 & dom.sweep.allele$ac.L==0)

#RC vs. LR
bre.sweep.allele=allele.sweep("sweep_breeding.reg")
dim(bre.sweep.allele)[1]
sum(bre.sweep.allele$ac.L==no.L & bre.sweep.allele$ac.R==no.R)
sum(bre.sweep.allele$ac.L<no.L & bre.sweep.allele$ac.R==no.R)
sum(bre.sweep.allele$ac.L==no.L & bre.sweep.allele$ac.R<no.R)
sum(bre.sweep.allele$ac.L>0 & bre.sweep.allele$ac.R>0 & bre.sweep.allele$ac.L<no.L &
	bre.sweep.allele$ac.R<no.R & (bre.sweep.allele$ac.L/no.L < bre.sweep.allele$ac.R/no.R))
sum(bre.sweep.allele$ac.L>0 & bre.sweep.allele$ac.R>0 & bre.sweep.allele$ac.L<no.L &
	bre.sweep.allele$ac.R<no.R & (bre.sweep.allele$ac.L/no.L > bre.sweep.allele$ac.R/no.R))
sum(bre.sweep.allele$ac.L>0 & bre.sweep.allele$ac.R==0)
sum(bre.sweep.allele$ac.W>0 & bre.sweep.allele$ac.L==0 & bre.sweep.allele$ac.R>0)
sum(bre.sweep.allele$ac.W==0 & bre.sweep.allele$ac.L==0 & bre.sweep.allele$ac.R>0)
sum(bre.sweep.allele$ac.L==0 & bre.sweep.allele$ac.R==0)

#Step 5: The successive allele changes from WA to LR and then to RC
sum(allele.count$ac.W>0 & allele.count$ac.L==0 & allele.count$ac.R==0)
sum(allele.count$ac.W>0 & allele.count$ac.L==0 & allele.count$ac.R>0)

sum(allele.count$ac.W==0 & allele.count$ac.L>0 & allele.count$ac.R==0)
sum(allele.count$ac.W==0 & allele.count$ac.L>0 & allele.count$ac.R>0)

sum(allele.count$ac.W<no.W & allele.count$ac.L==no.L & allele.count$ac.R==no.R)
sum(allele.count$ac.W<no.W & allele.count$ac.L==no.L & allele.count$ac.R<no.R)

sum(allele.count$ac.W==no.W & allele.count$ac.L<no.L & allele.count$ac.R==no.R)
sum(allele.count$ac.W==no.W & allele.count$ac.L<no.L & allele.count$ac.R<no.R)

sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W &
	allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L) & allele.count$ac.R==0)
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W &
	allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L) & allele.count$ac.R==no.R)
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R>0 &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & allele.count$ac.R<no.R &
	(allele.count$ac.W/no.W < allele.count$ac.L/no.L) & (allele.count$ac.L/no.L < allele.count$ac.R/no.R))
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R>0 &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & allele.count$ac.R<no.R &
	(allele.count$ac.W/no.W < allele.count$ac.L/no.L) & (allele.count$ac.L/no.L > allele.count$ac.R/no.R))

sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W & allele.count$ac.L<no.L &
	(allele.count$ac.W/no.W > allele.count$ac.L/no.L) & allele.count$ac.R==0)
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W & allele.count$ac.L<no.L &
	(allele.count$ac.W/no.W > allele.count$ac.L/no.L) & allele.count$ac.R==no.R)
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W & allele.count$ac.L<no.L &
	allele.count$ac.R>0 & allele.count$ac.R<no.R & (allele.count$ac.W/no.W > allele.count$ac.L/no.L) &
	(allele.count$ac.L/no.L < allele.count$ac.R/no.R))
sum(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W & allele.count$ac.L<no.L&
	allele.count$ac.R>0 & allele.count$ac.R<no.R & (allele.count$ac.W/no.W > allele.count$ac.L/no.L) &
	(allele.count$ac.L/no.L > allele.count$ac.R/no.R))

#Step 6: The summary of allele differences
allele.frequency.diff=function(mydataline) {
  table(cut(mydataline,breaks = c(0,0.1,0.2,0.3,0.5,0.7,0.9,1)))
}
#LR vs. WA
allele.count$diff.WtoL=abs(allele.count$ac.W/no.W - allele.count$ac.L/no.L)
allele.frequency.diff(allele.count$diff.WtoL[allele.count$ac.W==0 & allele.count$ac.L>0])
allele.frequency.diff(allele.count$diff.WtoL[allele.count$ac.W>0 & allele.count$ac.L==0])
allele.frequency.diff(allele.count$diff.WtoL[allele.count$ac.W<no.W & allele.count$ac.L==no.L])
allele.frequency.diff(allele.count$diff.WtoL[allele.count$ac.W==no.W & allele.count$ac.L<no.L])
allele.frequency.diff(allele.count$diff.WtoL[allele.count$ac.W>0 & allele.count$ac.L>0 &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L)])
allele.frequency.diff(allele.count$diff.WtoL[allele.count$ac.W>0 & allele.count$ac.L>0 &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W > allele.count$ac.L/no.L)])

#RC vs. LR
allele.count$diff.LtoR=abs(allele.count$ac.L/no.L - allele.count$ac.R/no.R)
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.W>0 & allele.count$ac.L==0 & allele.count$ac.R>0])
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.W==0 & allele.count$ac.L==0 & allele.count$ac.R>0])
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.L>0 & allele.count$ac.R==0])
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.L<no.L & allele.count$ac.R==no.R])
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.L==no.L & allele.count$ac.R<no.R])
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.L>0 & allele.count$ac.R>0 &
	allele.count$ac.L<no.L & allele.count$ac.R<no.R & (allele.count$ac.L/no.L < allele.count$ac.R/no.R)])
allele.frequency.diff(allele.count$diff.LtoR[allele.count$ac.L>0 & allele.count$ac.R>0 &
	allele.count$ac.L<no.L & allele.count$ac.R<no.R & (allele.count$ac.L/no.L > allele.count$ac.R/no.R)])

#Step 7: The evolutionary mechanism of sub-populations
#W.NC vs. W.SC
allele.count$diff.WSCtoWNC=abs(allele.count$ac.W.NC/no.W.NC - allele.count$ac.W.SC/no.W.SC)
allele.frequency.diff(allele.count$diff.WSCtoWNC[allele.count$ac.W.SC==0 & allele.count$ac.W.NC>0])
allele.frequency.diff(allele.count$diff.WSCtoWNC[allele.count$ac.W.SC>0 & allele.count$ac.W.NC==0])
allele.frequency.diff(allele.count$diff.WSCtoWNC[allele.count$ac.W.SC<no.W.SC & allele.count$ac.W.NC==no.W.NC])
allele.frequency.diff(allele.count$diff.WSCtoWNC[allele.count$ac.W.SC==no.W.SC & allele.count$ac.W.NC<no.W.NC])
allele.frequency.diff(allele.count$diff.WSCtoWNC[allele.count$ac.W.SC>0 & allele.count$ac.W.NC>0 &
	allele.count$ac.W.SC<no.W.SC & allele.count$ac.W.NC<no.W.NC & (allele.count$ac.W.SC/no.W.SC < allele.count$ac.W.NC/no.W.NC)])
allele.frequency.diff(allele.count$diff.WSCtoWNC[allele.count$ac.W.SC>0 & allele.count$ac.W.NC>0 &
	allele.count$ac.W.SC<no.W.SC & allele.count$ac.W.NC<no.W.NC & (allele.count$ac.W.SC/no.W.SC > allele.count$ac.W.NC/no.W.NC)])

#W.NEC vs. W.NC
allele.count$diff.WNCtoWNEC=abs(allele.count$ac.W.NEC/no.W.NEC - allele.count$ac.W.NC/no.W.NC)
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.SC>0 & allele.count$ac.W.NC==0 & allele.count$ac.W.NEC>0])
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.SC==0 & allele.count$ac.W.NC==0 & allele.count$ac.W.NEC>0])
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.NC>0 & allele.count$ac.W.NEC==0])
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.NC<no.W.NC & allele.count$ac.W.NEC==no.W.NEC])
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.NC==no.W.NC & allele.count$ac.W.NEC<no.W.NEC])
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.NC>0 & allele.count$ac.W.NEC>0 &
	allele.count$ac.W.NC<no.W.NC & allele.count$ac.W.NEC<no.W.NEC & (allele.count$ac.W.NC/no.W.NC < allele.count$ac.W.NEC/no.W.NEC)])
allele.frequency.diff(allele.count$diff.WNCtoWNEC[allele.count$ac.W.NC>0 & allele.count$ac.W.NEC>0 &
	allele.count$ac.W.NC<no.W.NC & allele.count$ac.W.NEC<no.W.NEC & (allele.count$ac.W.NC/no.W.NC > allele.count$ac.W.NEC/no.W.NEC)])

#L.NC vs. L.SC
allele.count$diff.LSCtoLNC=abs(allele.count$ac.L.NC/no.L.NC - allele.count$ac.L.SC/no.L.SC)
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.W>0 & allele.count$ac.L.SC==0 & allele.count$ac.L.NC>0])
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.W==0 & allele.count$ac.L.SC==0 & allele.count$ac.L.NC>0])
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.L.SC>0 & allele.count$ac.L.NC==0])
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.L.SC<no.L.SC & allele.count$ac.L.NC==no.L.NC])
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.L.SC==no.L.SC & allele.count$ac.L.NC<no.L.NC])
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.L.SC>0 & allele.count$ac.L.NC>0 &
	allele.count$ac.L.SC<no.L.SC & allele.count$ac.L.NC<no.L.NC & (allele.count$ac.L.SC/no.L.SC < allele.count$ac.L.NC/no.L.NC)])
allele.frequency.diff(allele.count$diff.LSCtoLNC[allele.count$ac.L.SC>0 & allele.count$ac.L.NC>0 &
    allele.count$ac.L.SC<no.L.SC & allele.count$ac.L.NC<no.L.NC & (allele.count$ac.L.SC/no.L.SC > allele.count$ac.L.NC/no.L.NC)])

#L.NEC vs. L.NC
allele.count$diff.LNCtoLNEC=abs(allele.count$ac.L.NEC/no.L.NEC - allele.count$ac.L.NC/no.L.NC)
allele.frequency.diff(allele.count$diff.LNCtoLNEC[
	(allele.count$ac.W>0 | allele.count$ac.L.SC>0 ) & allele.count$ac.L.NC==0 & allele.count$ac.L.NEC>0])
allele.frequency.diff(allele.count$diff.LNCtoLNEC[
  allele.count$ac.W==0 & allele.count$ac.L.SC==0 & allele.count$ac.L.NC==0 & allele.count$ac.L.NEC>0])
allele.frequency.diff(allele.count$diff.LNCtoLNEC[allele.count$ac.L.NC>0 & allele.count$ac.L.NEC==0])
allele.frequency.diff(allele.count$diff.LNCtoLNEC[allele.count$ac.L.NC<no.L.NC & allele.count$ac.L.NEC==no.L.NEC])
allele.frequency.diff(allele.count$diff.LNCtoLNEC[allele.count$ac.L.NC==no.L.NC & allele.count$ac.L.NEC<no.L.NEC])
allele.frequency.diff(allele.count$diff.LNCtoLNEC[allele.count$ac.L.NC>0 & allele.count$ac.L.NEC>0 &
	allele.count$ac.L.NC<no.L.NC & allele.count$ac.L.NEC<no.L.NEC & (allele.count$ac.L.NC/no.L.NC < allele.count$ac.L.NEC/no.L.NEC)])
allele.frequency.diff(allele.count$diff.LNCtoLNEC[allele.count$ac.L.NC>0 & allele.count$ac.L.NEC>0 &
	allele.count$ac.L.NC<no.L.NC & allele.count$ac.L.NEC<no.L.NEC & (allele.count$ac.L.NC/no.L.NC > allele.count$ac.L.NEC/no.L.NEC)])

#R.SC vs. L.SC
allele.count$diff.LSCtoRSC=abs(allele.count$ac.R.SC/no.R.SC - allele.count$ac.L.SC/no.L.SC)
allele.frequency.diff(allele.count$diff.LSCtoRSC[
	(allele.count$ac.W>0 | allele.count$ac.L>0 ) & allele.count$ac.L.SC==0 & allele.count$ac.R.SC>0])
allele.frequency.diff(allele.count$diff.LSCtoRSC[
	allele.count$ac.W==0 & allele.count$ac.L==0 & allele.count$ac.L.SC==0 & allele.count$ac.R.SC>0])
allele.frequency.diff(allele.count$diff.LSCtoRSC[allele.count$ac.L.SC>0 & allele.count$ac.R.SC==0])
allele.frequency.diff(allele.count$diff.LSCtoRSC[allele.count$ac.L.SC<no.L.SC & allele.count$ac.R.SC==no.R.SC])
allele.frequency.diff(allele.count$diff.LSCtoRSC[allele.count$ac.L.SC==no.L.SC & allele.count$ac.R.SC<no.R.SC])
allele.frequency.diff(allele.count$diff.LSCtoRSC[allele.count$ac.L.SC>0 & allele.count$ac.R.SC>0 &
	allele.count$ac.L.SC<no.L.SC & allele.count$ac.R.SC<no.R.SC & (allele.count$ac.L.SC/no.L.SC < allele.count$ac.R.SC/no.R.SC)])
allele.frequency.diff(allele.count$diff.LSCtoRSC[allele.count$ac.L.SC>0 & allele.count$ac.R.SC>0 &
    allele.count$ac.L.SC<no.L.SC & allele.count$ac.R.SC<no.R.SC & (allele.count$ac.L.SC/no.L.SC > allele.count$ac.R.SC/no.R.SC)])

#R.NC vs. L.NC
allele.count$diff.LNCtoRNC=abs(allele.count$ac.R.NC/no.R.NC - allele.count$ac.L.NC/no.L.NC)
allele.frequency.diff(allele.count$diff.LNCtoRNC[
  (allele.count$ac.W>0 | allele.count$ac.L>0 ) & allele.count$ac.L.NC==0 & allele.count$ac.R.NC>0])
allele.frequency.diff(allele.count$diff.LNCtoRNC[
  allele.count$ac.W==0 & allele.count$ac.L==0  & allele.count$ac.L.NC==0 & allele.count$ac.R.NC>0])
allele.frequency.diff(allele.count$diff.LNCtoRNC[allele.count$ac.L.NC>0 & allele.count$ac.R.NC==0])
allele.frequency.diff(allele.count$diff.LNCtoRNC[allele.count$ac.L.NC<no.L.NC & allele.count$ac.R.NC==no.R.NC])
allele.frequency.diff(allele.count$diff.LNCtoRNC[allele.count$ac.L.NC==no.L.NC & allele.count$ac.R.NC<no.R.NC])
allele.frequency.diff(allele.count$diff.LNCtoRNC[allele.count$ac.L.NC>0 & allele.count$ac.R.NC>0 &
	allele.count$ac.L.NC<no.L.NC & allele.count$ac.R.NC<no.R.NC & (allele.count$ac.L.NC/no.L.NC < allele.count$ac.R.NC/no.R.NC)])
allele.frequency.diff(allele.count$diff.LNCtoRNC[allele.count$ac.L.NC>0 & allele.count$ac.R.NC>0 &
    allele.count$ac.L.NC<no.L.NC & allele.count$ac.R.NC<no.R.NC & (allele.count$ac.L.NC/no.L.NC > allele.count$ac.R.NC/no.R.NC)])

#R.NEC vs. L.NEC
allele.count$diff.LNECtoRNEC=abs(allele.count$ac.R.NEC/no.R.NEC - allele.count$ac.L.NEC/no.L.NEC)
allele.frequency.diff(allele.count$diff.LNECtoRNEC[
  (allele.count$ac.W>0 | allele.count$ac.L>0 ) & allele.count$ac.L.NEC==0 & allele.count$ac.R.NEC>0])
allele.frequency.diff(allele.count$diff.LNECtoRNEC[
  allele.count$ac.W==0 & allele.count$ac.L==0  & allele.count$ac.L.NEC==0 & allele.count$ac.R.NEC>0])
allele.frequency.diff(allele.count$diff.LNECtoRNEC[allele.count$ac.L.NEC>0 & allele.count$ac.R.NEC==0])
allele.frequency.diff(allele.count$diff.LNECtoRNEC[allele.count$ac.L.NEC<no.L.NEC & allele.count$ac.R.NEC==no.R.NEC])
allele.frequency.diff(allele.count$diff.LNECtoRNEC[allele.count$ac.L.NEC==no.L.NEC & allele.count$ac.R.NEC<no.R.NEC])
allele.frequency.diff(allele.count$diff.LNECtoRNEC[allele.count$ac.L.NEC>0 & allele.count$ac.R.NEC>0 &
	allele.count$ac.L.NEC<no.L.NEC & allele.count$ac.R.NEC<no.R.NEC & (allele.count$ac.L.NEC/no.L.NEC < allele.count$ac.R.NEC/no.R.NEC)])
allele.frequency.diff(allele.count$diff.LNECtoRNEC[allele.count$ac.L.NEC>0 & allele.count$ac.R.NEC>0 &
    allele.count$ac.L.NEC<no.L.NEC & allele.count$ac.R.NEC<no.R.NEC & (allele.count$ac.L.NEC/no.L.NEC > allele.count$ac.R.NEC/no.R.NEC)])

#Step 8: The locus polymorphism disappeared and emerged
locus.no=function(tf) {
  length(levels(as.factor(allele.count[tf,1])))
}
locus.no(T)
locus.no(allele.count$ac.W==no.W)
locus.no(allele.count$ac.L==no.L)
locus.no(allele.count$ac.R==no.R)
locus.no(allele.count$ac.W<no.W & allele.count$ac.L==no.L)
locus.no(allele.count$ac.W<no.W & allele.count$ac.L==no.L & allele.count$ac.R==no.R)
locus.no(allele.count$ac.W<no.W & allele.count$ac.L==no.L & allele.count$ac.R<no.R)
locus.no(allele.count$ac.W==no.W & allele.count$ac.L<no.L)
locus.no(allele.count$ac.W==no.W & allele.count$ac.L<no.L & allele.count$ac.R==no.R)
locus.no(allele.count$ac.W==no.W & allele.count$ac.L<no.L & allele.count$ac.R<no.R &
	allele.count$ac.L/no.L < allele.count$ac.R/no.R)
locus.no(allele.count$ac.W==no.W & allele.count$ac.L<no.L & allele.count$ac.R>0 &
	allele.count$ac.L/no.L > allele.count$ac.R/no.R)
locus.no(allele.count$ac.W==no.W & allele.count$ac.L<no.L & allele.count$ac.R==0)
locus.no(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R==no.R &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L))
locus.no(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R==no.R &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L) &
	allele.count$ac.L/no.L<0.9)
locus.no(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R==no.R &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L) &
	allele.count$ac.L/no.L>=0.9 & allele.count$ac.L/no.L<0.95)
locus.no(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R==no.R &
	allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L) &
    allele.count$ac.L/no.L>=0.95)
locus.no(allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.R==no.R &
    allele.count$ac.W<no.W & allele.count$ac.L<no.L & (allele.count$ac.W/no.W > allele.count$ac.L/no.L))
locus.no(allele.count$ac.W==no.W & allele.count$ac.L==no.L & allele.count$ac.R<no.R)

#Step 9: The locus no. with allele zero/one or ordinary frequency changes
#LR vs. WA
locus.name=function(tf) {
  levels(as.factor(allele.count[tf,1]))
}
match.name=function(line1,line2) line2[match(line1,line2,nomatch = 0)]
WtoL.allele.01.changed.name=locus.name((allele.count$ac.W>0 & allele.count$ac.L==0) |
           (allele.count$ac.W==0 & allele.count$ac.L>0))
WtoL.allele.ordinary.changed.name=locus.name(allele.count$ac.W>0 & allele.count$ac.L>0 &
           allele.count$ac.W<no.W & allele.count$ac.L<no.L)
length(WtoL.allele.01.changed.name)
length(WtoL.allele.ordinary.changed.name)
length(match.name(WtoL.allele.01.changed.name,WtoL.allele.ordinary.changed.name))
locus.no(allele.count$ac.W==no.W & allele.count$ac.L==no.L)
#RC vs. LR
LtoR.allele.01.changed.name=locus.name((allele.count$ac.L>0 & allele.count$ac.R==0) |
(allele.count$ac.W==0 & allele.count$ac.L==0 & allele.count$ac.R>0))
LtoR.allele.ordinary.changed.name=locus.name(allele.count$ac.L>0 & allele.count$ac.R>0 &
	allele.count$ac.L<no.L & allele.count$ac.R<no.R)
length(LtoR.allele.01.changed.name)
length(LtoR.allele.ordinary.changed.name)
length(match.name(LtoR.allele.01.changed.name,LtoR.allele.ordinary.changed.name))
locus.no(allele.count$ac.R==no.R & allele.count$ac.L==no.L)

#Step 10: The genome position of zero/one changes and large difference ordinary frequency changes
plot.density <- function(chr, pos, w=1e6,peri=NULL, emerged=NULL, excluded=NULL) {
  chrom <- unique(chr)
  nchr <- length(chrom)
  w.breaks <- list()
  w.counts <- list()
  x.peri <- list()
  x.new <- list()
  x.del <- list()
  for (i in 1:nchr) {
    bp <- pos[chr == chrom[i]]
    w.breaks[[i]] <- seq(0, ceiling(max(bp)/w)*w, w)
    w.counts[[i]] <- hist(bp, w.breaks[[i]], plot=FALSE)$counts
    x.peri[[i]] <- subset(peri, CHR==chrom[i])
    x.new[[i]] <- subset(emerged, CHR==chrom[i])$BP
    x.del[[i]] <- subset(excluded, CHR==chrom[i])$BP
  }
  
  cnt <- unlist(w.counts)
  cnt.max <- max(cnt)
  cnt.bin <- c(0, quantile(cnt[cnt>0],seq(0,1,0.1),type=2))
  
  col <- c("#e5f5e0", "#4daf4a")
  col <- c("gray", colorRampPalette(col)(length(cnt.bin) - 2))
  
  w.colors <- list()
  for (i in 1:nchr) {
    idx <- findInterval(w.counts[[i]], cnt.bin, rightmost.closed=TRUE)
    w.colors[[i]] <- col[idx]
  }
  
  xmax <- max( sapply(w.breaks, max) )
  xtick.lab <- pretty( c(0, xmax / w) )
  xtick.pos <- xtick.lab * w
  xlim <- c(0, max(xmax, xtick.pos))
  ylim <- c(0, 1.2 * nchr)
  
  plot(NULL, xlim=xlim, ylim=ylim, axes=FALSE, xlab=NA, ylab=NA, xaxs="i", yaxs="i")
  
  ymin <- 0
  ytick.pos <- rep(0, nchr)
  for (i in 1:nchr) {
    x <- w.breaks[[i]]
    rect(head(x,-1), ymin, tail(x,-1), ymin + 0.4, col=w.colors[[i]], border=NA)
    segments(x.peri[[i]][1,2],ymin + 0.2 ,x1 = x.peri[[i]][1,3],col ="black" )
    segments(x.new[[i]], ymin+0.4, y1=ymin+0.7, col="#377eb8", lwd=0.1)
    segments(x.del[[i]], ymin+0.7, y1=ymin+1.0, col="#e41a1c", lwd=0.1)
    ytick.pos[i] <- ymin + 0.5
    ymin <- ymin + 1.2
  }
  
  axis(1, at=xtick.pos, labels=xtick.lab, cex.axis=0.8, mgp=c(0,0.3,0), tcl=-0.3)
  axis(2, at=ytick.pos, labels=chrom, cex.axis=0.8, mgp=c(0,0.6,0), tcl=-0.3, las=1, lwd=0, hadj=0.5)
  title(xlab="Position (Mb)", line=1.5)
  title(ylab="Chromosome", line=1.5)
  
  list(bin=cnt.bin, col=col)
}
plot.colorbar <- function(bin, col) {
  n <- length(col)
  plot(NULL, xlim=c(0,1), ylim=c(0,n), axes=FALSE, xlab=NA, ylab=NA, xaxs="i")
  for (i in 1:n)
    rect(0, i-1, 1, i, col=col[i], border=NA)
  axis(4, at=(0:n), labels=bin, cex.axis=0.8, mgp=c(0,0.3,0), tcl=-0.2, las=1)
}
emerged.excluded.pos.plot=function(
    ldb.pos.file,peri.file,emerged.pos.file,excluded.pos.file,outfile) {
  d <- ldb.pos.file
  d1 <- emerged.pos.file
  d2 <- excluded.pos.file
  colnames(d1) <- c("loc","CHR","BP","allele")
  colnames(d2) <- c("loc","CHR","BP","allele")
  colnames(d) <- c("CHR","BP")
  
  pdf(outfile, width=18/2.54, height=20/2.54, pointsize=10)
  layout(matrix(c(1,2),1,2), widths=c(16.5,1.5)/18)
  par(mar=c(3,3,1,1), lend=2)
  try( colorbar <- plot.density(d$CHR, d$BP,peri=peri.file, emerged=d1, excluded=d2) )
  par(mar=c(30,0,4,2.5), lend=2)
  try( plot.colorbar(colorbar$bin, colorbar$col) )
  dev.off()
  
}

snpldb.pos=allele.count[!c(F,allele.count[-1,3]==allele.count[-dim(allele.count)[1],3]),2:3]
peri.pos=read.table("peri.txt",header = T)
WtoL.allele.emerged.pos=allele.count[allele.count$ac.W==0 & allele.count$ac.L>0,1:4]
WtoL.allele.excluded.pos=allele.count[allele.count$ac.W>0 & allele.count$ac.L==0,1:4]
emerged.excluded.pos.plot(snpldb.pos,peri.pos,WtoL.allele.emerged.pos,WtoL.allele.excluded.pos,"WtoL.allele01.pdf")

WtoL.locus.emerged.pos=allele.count[allele.count$ac.W==no.W & allele.count$ac.L<no.L,1:4]
WtoL.locus.excluded.pos=allele.count[allele.count$ac.W<no.W & allele.count$ac.L==no.L,1:4]
emerged.excluded.pos.plot(snpldb.pos,peri.pos,WtoL.locus.emerged.pos,WtoL.locus.excluded.pos,"WtoL.locus01.pdf")

LtoR.allele.emerged.pos=allele.count[allele.count$ac.W==0 & allele.count$ac.L==0 & allele.count$ac.R>0,1:4]
LtoR.allele.excluded.pos=allele.count[allele.count$ac.L>0 & allele.count$ac.R==0,1:4]
emerged.excluded.pos.plot(snpldb.pos,peri.pos,LtoR.allele.emerged.pos,LtoR.allele.excluded.pos,"LtoR.allele01.pdf")

LtoR.locus.emerged.pos=allele.count[allele.count$ac.L==no.L & allele.count$ac.R<no.R,1:4]
LtoR.locus.excluded.pos=allele.count[allele.count$ac.L<no.L & allele.count$ac.R==no.R,1:4]
emerged.excluded.pos.plot(snpldb.pos,peri.pos,LtoR.locus.emerged.pos,LtoR.locus.excluded.pos,"LtoR.locus01.pdf")


WtoL.ord.inc.pos=allele.count[allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W &
allele.count$ac.L<no.L & (allele.count$ac.W/no.W < allele.count$ac.L/no.L) & allele.count$diff.WtoL>0.1 ,1:4]
WtoL.ord.dec.pos=allele.count[allele.count$ac.W>0 & allele.count$ac.L>0 & allele.count$ac.W<no.W &
allele.count$ac.L<no.L & (allele.count$ac.W/no.W > allele.count$ac.L/no.L) & allele.count$diff.WtoL>0.1 ,1:4]
emerged.excluded.pos.plot(snpldb.pos,peri.pos,WtoL.ord.inc.pos,WtoL.ord.dec.pos,"WtoL.ordinary.pdf")

LtoR.ord.inc.pos=allele.count[allele.count$ac.L>0 & allele.count$ac.R>0 & allele.count$ac.L<no.L &
allele.count$ac.R<no.R & (allele.count$ac.L/no.L < allele.count$ac.R/no.R) & allele.count$diff.LtoR>0.1 ,1:4]
LtoR.ord.dec.pos=allele.count[allele.count$ac.L>0 & allele.count$ac.R>0 & allele.count$ac.L<no.L &
allele.count$ac.R<no.R & (allele.count$ac.L/no.L > allele.count$ac.R/no.R) & allele.count$diff.LtoR>0.1 ,1:4]
emerged.excluded.pos.plot(snpldb.pos,peri.pos,LtoR.ord.inc.pos,LtoR.ord.dec.pos,"LtoR.ordinary.pdf")

