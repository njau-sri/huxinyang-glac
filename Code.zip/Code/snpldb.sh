#!/bin/sh
rtm-gwas-snpldb --thread 12 --vcf snp.vcf --maxlen 200000 --maf 0.01 --out snpldb
