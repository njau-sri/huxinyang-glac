#!/bin/sh
vcftools --vcf snpldb.vcf  --weir-fst-pop w-type.txt --weir-fst-pop l-type.txt --out wtol
vcftools --vcf snpldb.vcf  --weir-fst-pop l-type.txt --weir-fst-pop r-type.txt --out ltor
vcftools --vcf snpldb.vcf  --weir-fst-pop w.sc.txt --weir-fst-pop w.nc.txt --out wsctownc
vcftools --vcf snpldb.vcf  --weir-fst-pop w.nc.txt --weir-fst-pop w.nec.txt --out wnctownec
vcftools --vcf snpldb.vcf  --weir-fst-pop w.sc.txt --weir-fst-pop l.sc.txt --out wsctolsc
vcftools --vcf snpldb.vcf  --weir-fst-pop l.sc.txt --weir-fst-pop l.nc.txt --out lsctolnc
vcftools --vcf snpldb.vcf  --weir-fst-pop l.nc.txt --weir-fst-pop l.nec.txt --out lnctolnec
vcftools --vcf snpldb.vcf  --weir-fst-pop l.sc.txt --weir-fst-pop r.sc.txt --out lsctorsc
vcftools --vcf snpldb.vcf  --weir-fst-pop l.nc.txt --weir-fst-pop r.nc.txt --out lnctornc
vcftools --vcf snpldb.vcf  --weir-fst-pop l.nec.txt --weir-fst-pop r.nec.txt --out lnectornec
vcftools --vcf snpldb.vcf  --weir-fst-pop r.sc.txt --weir-fst-pop r.nc.txt --out rsctornc
vcftools --vcf snpldb.vcf  --weir-fst-pop r.nc.txt --weir-fst-pop r.nec.txt --out rnctorsc
