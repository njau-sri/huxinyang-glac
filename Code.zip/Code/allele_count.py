#！usr/bin/python3

import sys

indpop = dict()
with open(sys.argv[2]) as f:
    for line in f:
        v = line.split()
        indpop[v[0]] = v[1]
pop = list(set(indpop.values()))

print ("loc"+" "+"chr"+" "+"pos"+" "+"allele"+" "+"ac", end=" ")
for e in pop:
    print ("ac.{0}".format(e), end=" ")
print()

with open(sys.argv[1]) as f:
    for line in f.readlines():
        if line.startswith("##"):
            continue
        elif line.startswith("#CHROM"):
            ind = line.split()[9:]
            idx = [[] for _ in range(len(pop))]
            for i in range(len(ind)):
                j = pop.index(indpop[ind[i]])
                idx[j].append(i)
        else: 
            v = line.split()
            g = v[9:]
            gp = []
            for pi in idx:
                gp.append([g[i] for i in pi])
            for a in set(g):
                ac = g.count(a)
                print (v[2], v[0], v[1], a, ac, end=" ")
                for gi in gp:
                    ac = gi.count(a)
                    print (ac, end=" ")
                print()