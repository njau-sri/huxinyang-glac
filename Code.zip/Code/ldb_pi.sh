#!/bin/sh
vcftools --vcf snpldb.vcf  --keep w-type.txt --site-pi --out w
vcftools --vcf snpldb.vcf  --keep l-type.txt --site-pi --out l
vcftools --vcf snpldb.vcf  --keep r-type.txt --site-pi --out r
vcftools --vcf snpldb.vcf  --keep w.sc.txt --site-pi --out w.sc
vcftools --vcf snpldb.vcf  --keep w.nc.txt --site-pi --out w.nc
vcftools --vcf snpldb.vcf  --keep w.nec.txt --site-pi --out w.nec
vcftools --vcf snpldb.vcf  --keep l.sc.txt --site-pi --out l.sc
vcftools --vcf snpldb.vcf  --keep l.nc.txt --site-pi --out l.nc
vcftools --vcf snpldb.vcf  --keep l.nec.txt --site-pi --out l.nec
vcftools --vcf snpldb.vcf  --keep r.sc.txt --site-pi --out r.sc
vcftools --vcf snpldb.vcf  --keep r.nc.txt --site-pi --out r.nc
vcftools --vcf snpldb.vcf  --keep r.nec.txt --site-pi --out r.nec
